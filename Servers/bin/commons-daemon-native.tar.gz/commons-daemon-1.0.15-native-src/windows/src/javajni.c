/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "apxwin.h"
#include "handles.h"
#include "javajni.h"
#include "private.h"

#include <jni.h>

#ifndef JNI_VERSION_1_2
#error -------------------------------------------------------
#error JAVA 1.1 IS NO LONGER SUPPORTED
#error -------------------------------------------------------
#endif

#ifdef JNI_VERSION_1_4
#define JNI_VERSION_DEFAULT JNI_VERSION_1_4
#else
#define JNI_VERSION_DEFAULT JNI_VERSION_1_2
#endif

/* Standard jvm.dll prototypes
 * since only single jvm can exist per process
 * make those global
 */

DYNOLAD_TYPE_DECLARE(JNI_GetDefaultJavaVMInitArgs, JNICALL, jint)(void *);
static DYNLOAD_FPTR_DECLARE(JNI_GetDefaultJavaVMInitArgs) = NULL;

DYNOLAD_TYPE_DECLARE(JNI_CreateJavaVM, JNICALL, jint)(JavaVM **, void **, void *);
static DYNLOAD_FPTR_DECLARE(JNI_CreateJavaVM) = NULL;

DYNOLAD_TYPE_DECLARE(JNI_GetCreatedJavaVMs, JNICALL, jint)(JavaVM **, jsize, jsize *);
static DYNLOAD_FPTR_DECLARE(JNI_GetCreatedJavaVMs) = NULL;

DYNOLAD_TYPE_DECLARE(JVM_DumpAllStacks, JNICALL, void)(JNIEnv *, jclass);
static DYNLOAD_FPTR_DECLARE(JVM_DumpAllStacks) = NULL;

static HANDLE  _st_sys_jvmDllHandle = NULL;
static JavaVM *_st_sys_jvm = NULL;

DYNOLAD_TYPE_DECLARE(SetDllDirectoryW, WINAPI, BOOL)(LPCWSTR);
static DYNLOAD_FPTR_DECLARE(SetDllDirectoryW) = NULL;

#define JVM_DELETE_CLAZZ(jvm, cl)                                               \
    APXMACRO_BEGIN                                                              \
    if ((jvm)->lpEnv && (jvm)->cl.jClazz) {                                   \
        (*((jvm)->lpEnv))->DeleteGlobalRef((jvm)->lpEnv, (jvm)->cl.jClazz);   \
        (jvm)->cl.jClazz = NULL;                                              \
    } APXMACRO_END

#define JVM_EXCEPTION_CHECK(jvm) \
    ((*((jvm)->lpEnv))->ExceptionCheck((jvm)->lpEnv) != JNI_OK)

#define JVM_EXCEPTION_CLEAR(jvm) \
    APXMACRO_BEGIN                                              \
    if ((jvm)->lpEnv) {                                         \
        if ((*((jvm)->lpEnv))->ExceptionCheck((jvm)->lpEnv)) {  \
            (*((jvm)->lpEnv))->ExceptionDescribe((jvm)->lpEnv); \
            (*((jvm)->lpEnv))->ExceptionClear((jvm)->lpEnv);    \
        }                                                       \
    } APXMACRO_END

#define JNI_LOCAL_UNREF(obj) \
        (*(lpJava->lpEnv))->DeleteLocalRef(lpJava->lpEnv, obj)

#define JNICALL_0(fName)  \
        ((*(lpJava->lpEnv))->fName(lpJava->lpEnv))

#define JNICALL_1(fName, a1)  \
        ((*(lpJava->lpEnv))->fName(lpJava->lpEnv, (a1)))

#define JNICALL_2(fName, a1, a2)  \
        ((*(lpJava->lpEnv))->fName(lpJava->lpEnv, (a1), (a2)))

#define JNICALL_3(fName, a1, a2, a3)  \
        ((*(lpJava->lpEnv))->fName(lpJava->lpEnv, (a1), (a2), (a3)))

#define JNICALL_4(fName, a1, a2, a3, a4)  \
        ((*(lpJava->lpEnv))->fName(lpJava->lpEnv, (a1), (a2), (a3), (a4)))

typedef struct APXJAVASTDCLAZZ {
    CHAR        sClazz[1024];
    CHAR        sMethod[512];
    jclass      jClazz;
    jmethodID   jMethod;
    jobject     jObject;
    jarray      jArgs;
} APXJAVASTDCLAZZ, *LPAPXJAVASTDCLAZZ;

typedef struct APXJAVAVM {
    DWORD           dwOptions;
    APXJAVASTDCLAZZ clString;
    APXJAVASTDCLAZZ clWorker;
    jint            iVersion;
    jsize           iVmCount;
    JNIEnv          *lpEnv;
    JavaVM          *lpJvm;
    /* JVM worker thread info */
    HANDLE          hWorkerThread;
    DWORD           iWorkerThread;
    DWORD           dwWorkerStatus;
    SIZE_T          szStackSize;
    HANDLE          hWorkerSync;
    HANDLE          hWorkerInit;
} APXJAVAVM, *LPAPXJAVAVM;

/* This is no longer exported in jni.h
 * However java uses it internally to get
 * the default stack size
 */
typedef struct APX_JDK1_1InitArgs {
    jint version;

    char **properties;
    jint checkSource;
    jint nativeStackSize;
    jint javaStackSize;
    jint minHeapSize;
    jint maxHeapSize;
    jint verifyMode;
    char *classpath;

    char padding[128];
} APX_JDK1_1InitArgs;

#define JAVA_CLASSPATH      "-Djava.class.path="
#define JAVA_CLASSPATH_W    L"-Djava.class.path="
#define JAVA_CLASSSTRING    "java/lang/String"
#define MSVCRT71_DLLNAME    L"\\msvcrt71.dll"

static DWORD vmExitCode = 0;

static __inline BOOL __apxJvmAttachEnv(LPAPXJAVAVM lpJava, JNIEnv **lpEnv,
                                       LPBOOL lpAttached)
{
    jint _iStatus;

    if (!_st_sys_jvm || !lpJava->lpJvm)
      return FALSE;
    _iStatus = (*(lpJava->lpJvm))->GetEnv(lpJava->lpJvm,
                                          (void **)lpEnv,
                                          lpJava->iVersion);
    if (_iStatus != JNI_OK) {
        if (_iStatus == JNI_EDETACHED) {
            _iStatus = (*(lpJava->lpJvm))->AttachCurrentThread(lpJava->lpJvm,
                                                (void **)lpEnv, NULL);
            if (lpAttached)
                *lpAttached = TRUE;
        }
    }
    if (_iStatus != JNI_OK) {
        *lpEnv = NULL;
        return FALSE;
    }
    else
        return TRUE;
}

static __inline BOOL __apxJvmAttach(LPAPXJAVAVM lpJava)
{
    return __apxJvmAttachEnv(lpJava, &lpJava->lpEnv, NULL);
}

static __inline BOOL __apxJvmDetach(LPAPXJAVAVM lpJava)
{
    if (!_st_sys_jvm || !lpJava->lpJvm)
      return FALSE;
    if ((*(lpJava->lpJvm))->DetachCurrentThread(lpJava->lpJvm) != JNI_OK) {
        lpJava->lpEnv = NULL;
        return FALSE;
    }
    else
        return TRUE;
}

static BOOL __apxLoadJvmDll(LPCWSTR szJvmDllPath)
{
    UINT errMode;
    WCHAR  jreAltPath[SIZ_PATHLEN];
    LPWSTR dllJvmPath = (LPWSTR)szJvmDllPath;
    DYNLOAD_FPTR_DECLARE(SetDllDirectoryW);

    if (!IS_INVALID_HANDLE(_st_sys_jvmDllHandle))
        return TRUE;    /* jvm.dll is already loaded */

    if (dllJvmPath && *dllJvmPath) {
        /* Explicit JVM path.
         * Check if provided argument is valid
         */
        if (GetFileAttributesW(dllJvmPath) == INVALID_FILE_ATTRIBUTES) {
            /* DAEMON-247: Invalid RuntimeLib explicitly specified is error.
             */
            apxLogWrite(APXLOG_MARK_DEBUG "Invalid RuntimeLib specified '%S'", dllJvmPath);
            return FALSE;
        }
    }
    else {
        dllJvmPath = apxGetJavaSoftRuntimeLib(NULL);
        if (!dllJvmPath)
            return FALSE;
    }
    if (GetFileAttributesW(dllJvmPath) == INVALID_FILE_ATTRIBUTES) {
        /* DAEMON-184: RuntimeLib registry key is invalid.
         * Check from Jre JavaHome directly
         */
        LPWSTR szJreHome = apxGetJavaSoftHome(NULL, TRUE);
        apxLogWrite(APXLOG_MARK_DEBUG "Invalid RuntimeLib '%S'", dllJvmPath);
        if (szJreHome) {
            apxLogWrite(APXLOG_MARK_DEBUG "Using Jre JavaHome '%S'", szJreHome);
            lstrlcpyW(jreAltPath, SIZ_PATHLEN, szJreHome);
            lstrlcatW(jreAltPath, SIZ_PATHLEN, L"\\bin\\server\\jvm.dll");
            dllJvmPath = jreAltPath;
        }
    }
    /* Suppress the not found system popup message */
    errMode = SetErrorMode(SEM_FAILCRITICALERRORS);

    apxLogWrite(APXLOG_MARK_DEBUG "loading jvm '%S'", dllJvmPath);
    _st_sys_jvmDllHandle = LoadLibraryExW(dllJvmPath, NULL, 0);
    if (IS_INVALID_HANDLE(_st_sys_jvmDllHandle) &&
        GetFileAttributesW(dllJvmPath) != INVALID_FILE_ATTRIBUTES) {
        /* There is a file but cannot be loaded.
         * Try to load the MSVCRTxx.dll before JVM.dll
         */
        WCHAR  jreBinPath[SIZ_PATHLEN];
        WCHAR  crtBinPath[SIZ_PATHLEN];
        DWORD  i, l = 0;

        lstrlcpyW(jreBinPath, SIZ_PATHLEN, dllJvmPath);
        for (i = lstrlenW(jreBinPath); i > 0, l < 2; i--) {
            if (jreBinPath[i] == L'\\' || jreBinPath[i] == L'/') {
                jreBinPath[i] = L'\0';
                lstrlcpyW(crtBinPath, SIZ_PATHLEN, jreBinPath);
                lstrlcatW(crtBinPath, SIZ_PATHLEN, MSVCRT71_DLLNAME);
                if (GetFileAttributesW(crtBinPath) != INVALID_FILE_ATTRIBUTES) {
                    if (LoadLibraryW(crtBinPath)) {
                        /* Found MSVCRTxx.dll
                         */
                        apxLogWrite(APXLOG_MARK_DEBUG "preloaded '%S'",
                                    crtBinPath);
                        break;
                    }
                }
                l++;
            }
        }
    }
    /* This shuldn't happen, but try to search in %PATH% */
    if (IS_INVALID_HANDLE(_st_sys_jvmDllHandle))
        _st_sys_jvmDllHandle = LoadLibraryExW(dllJvmPath, NULL,
                                              LOAD_WITH_ALTERED_SEARCH_PATH);

    if (IS_INVALID_HANDLE(_st_sys_jvmDllHandle)) {
        WCHAR  jreBinPath[SIZ_PATHLEN];
        DWORD  i, l = 0;

        lstrlcpyW(jreBinPath, SIZ_PATHLEN, dllJvmPath);
        DYNLOAD_FPTR_ADDRESS(SetDllDirectoryW, KERNEL32);
        for (i = lstrlenW(jreBinPath); i > 0, l < 2; i--) {
            if (jreBinPath[i] == L'\\' || jreBinPath[i] == L'/') {
                jreBinPath[i] = L'\0';
                DYNLOAD_CALL(SetDllDirectoryW)(jreBinPath);
                apxLogWrite(APXLOG_MARK_DEBUG "Setting DLL search path to '%S'",
                            jreBinPath);
                l++;
            }
        }
        _st_sys_jvmDllHandle = LoadLibraryExW(dllJvmPath, NULL, 0);
        if (IS_INVALID_HANDLE(_st_sys_jvmDllHandle))
            _st_sys_jvmDllHandle = LoadLibraryExW(dllJvmPath, NULL,
                                                  LOAD_WITH_ALTERED_SEARCH_PATH);
    }
    /* Restore the error mode signalization */
    SetErrorMode(errMode);
    if (IS_INVALID_HANDLE(_st_sys_jvmDllHandle)) {
        apxLogWrite(APXLOG_MARK_SYSERR);
        return FALSE;
    }
    DYNLOAD_FPTR_LOAD(JNI_GetDefaultJavaVMInitArgs, _st_sys_jvmDllHandle);
    DYNLOAD_FPTR_LOAD(JNI_CreateJavaVM,             _st_sys_jvmDllHandle);
    DYNLOAD_FPTR_LOAD(JNI_GetCreatedJavaVMs,        _st_sys_jvmDllHandle);
    DYNLOAD_FPTR_LOAD(JVM_DumpAllStacks,            _st_sys_jvmDllHandle);

    if (!DYNLOAD_FPTR(JNI_GetDefaultJavaVMInitArgs) ||
        !DYNLOAD_FPTR(JNI_CreateJavaVM) ||
        !DYNLOAD_FPTR(JNI_GetCreatedJavaVMs)) {
        apxLogWrite(APXLOG_MARK_SYSERR);
        FreeLibrary(_st_sys_jvmDllHandle);
        _st_sys_jvmDllHandle = NULL;
        return FALSE;
    }

    /* Real voodo ... */
    return TRUE;
}

static BOOL __apxJavaJniCallback(APXHANDLE hObject, UINT uMsg,
                                 WPARAM wParam, LPARAM lParam)
{
    LPAPXJAVAVM lpJava;
    DWORD       dwJvmRet = 0;

    lpJava = APXHANDLE_DATA(hObject);
    switch (uMsg) {
        case WM_CLOSE:
            if (_st_sys_jvm && lpJava->lpJvm) {
                if (!IS_INVALID_HANDLE(lpJava->hWorkerThread)) {
                    if (GetExitCodeThread(lpJava->hWorkerThread, &dwJvmRet) &&
                        dwJvmRet == STILL_ACTIVE) {
                        TerminateThread(lpJava->hWorkerThread, 5);
                    }
                }
                SAFE_CLOSE_HANDLE(lpJava->hWorkerThread);
                __apxJvmAttach(lpJava);
                JVM_DELETE_CLAZZ(lpJava, clWorker);
                JVM_DELETE_CLAZZ(lpJava, clString);
                __apxJvmDetach(lpJava);
                /* Check if this is the jvm loader */
                if (!lpJava->iVmCount && _st_sys_jvmDllHandle) {
                    /* Unload JVM dll */
                    FreeLibrary(_st_sys_jvmDllHandle);
                    _st_sys_jvmDllHandle = NULL;
                }
                lpJava->lpJvm = NULL;
            }
        break;
        default:
        break;
    }
    return TRUE;
}

APXHANDLE
apxCreateJava(APXHANDLE hPool, LPCWSTR szJvmDllPath)
{

    APXHANDLE    hJava;
    LPAPXJAVAVM  lpJava;
    jsize        iVmCount;
    JavaVM       *lpJvm = NULL;
    struct       APX_JDK1_1InitArgs jArgs1_1;

    if (!__apxLoadJvmDll(szJvmDllPath))
        return NULL;


    /*
     */
    if (DYNLOAD_FPTR(JNI_GetCreatedJavaVMs)(&lpJvm, 1, &iVmCount) != JNI_OK) {
        return NULL;
    }
    if (iVmCount && !lpJvm)
        return NULL;

    hJava = apxHandleCreate(hPool, 0,
                            NULL, sizeof(APXJAVAVM),
                            __apxJavaJniCallback);
    if (IS_INVALID_HANDLE(hJava))
        return NULL;
    hJava->dwType = APXHANDLE_TYPE_JVM;
    lpJava = APXHANDLE_DATA(hJava);
    lpJava->lpJvm = lpJvm;
    lpJava->iVmCount = iVmCount;

    /* Guess the stack size
     */
    AplZeroMemory(&jArgs1_1, sizeof(jArgs1_1));
    jArgs1_1.version = JNI_VERSION_1_1;
    DYNLOAD_FPTR(JNI_GetDefaultJavaVMInitArgs)(&jArgs1_1);
    if (jArgs1_1.javaStackSize < 0 || jArgs1_1.javaStackSize > (2048 * 1024))
        jArgs1_1.javaStackSize = 0;
    lpJava->szStackSize = (SIZE_T)jArgs1_1.javaStackSize;

    if (!_st_sys_jvm)
        _st_sys_jvm = lpJvm;
    return hJava;
}

static DWORD WINAPI __apxJavaDestroyThread(LPVOID lpParameter)
{
    JavaVM *lpJvm = (JavaVM *)lpParameter;
    (*lpJvm)->DestroyJavaVM(lpJvm);
    return 0;
}

BOOL
apxDestroyJvm(DWORD dwTimeout)
{
    if (_st_sys_jvm) {
        DWORD  tid;
        HANDLE hWaiter;
        BOOL   rv = FALSE;
        JavaVM *lpJvm = _st_sys_jvm;

        _st_sys_jvm = NULL;
        (*lpJvm)->DetachCurrentThread(lpJvm);
        hWaiter = CreateThread(NULL, 0, __apxJavaDestroyThread,
                               (void *)lpJvm, 0, &tid);
        if (IS_INVALID_HANDLE(hWaiter)) {
            apxLogWrite(APXLOG_MARK_SYSERR);
            return FALSE;
        }
        if (WaitForSingleObject(hWaiter, dwTimeout) == WAIT_OBJECT_0)
            rv = TRUE;
        CloseHandle(hWaiter);
        return rv;
    }
    else
        return FALSE;
}

static DWORD __apxMultiSzToJvmOptions(APXHANDLE hPool,
                                      LPCSTR lpString,
                                      JavaVMOption **lppArray,
                                      DWORD  nExtra)
{
    DWORD i, n = 0, l = 0;
    char *buff;
    LPSTR p;

    if (lpString) {
        l = __apxGetMultiSzLengthA(lpString, &n);
    }
    n += nExtra;
    buff = apxPoolAlloc(hPool, (n + 1) * sizeof(JavaVMOption) + (l + 1));

    *lppArray = (JavaVMOption *)buff;
    p = (LPSTR)(buff + (n + 1) * sizeof(JavaVMOption));
    if (lpString)
        AplCopyMemory(p, lpString, l + 1);
    for (i = 0; i < (n - nExtra); i++) {
        DWORD qr = apxStrUnQuoteInplaceA(p);
        (*lppArray)[i].optionString = p;
        while (*p)
            p++;
        p++;
        p += qr;
    }

    return n;
}

/* a hook for a function that redirects all VM messages. */
static jint JNICALL __apxJniVfprintf(FILE *fp, const char *format, va_list args)
{
    jint rv;
    CHAR sBuf[1024+16];
    rv = wvsprintfA(sBuf, format, args);
    if (apxLogWrite(APXLOG_MARK_INFO "%s", sBuf) == 0)
        fputs(sBuf, stdout);
    return rv;
}

static void JNICALL __apxJniExit(jint exitCode)
{
    apxLogWrite(APXLOG_MARK_DEBUG "Exit hook with exit code %d", exitCode);
    vmExitCode = exitCode;
    return;
}

static LPSTR __apxStrIndexA(LPCSTR szStr, int nCh)
{
    LPSTR pStr;

    for (pStr = (LPSTR)szStr; *pStr; pStr++) {
        if (*pStr == nCh)
            return pStr;
    }
    return NULL;
}

static LPSTR __apxStrnCatA(APXHANDLE hPool, LPSTR pOrg, LPCSTR szStr, LPCSTR szAdd)
{
    DWORD len = 1;
    DWORD nas = pOrg == NULL;
    if (pOrg)
        len += lstrlenA(pOrg);
    if (szStr)
        len += lstrlenA(szStr);
    if (szAdd)
        len += lstrlenA(szAdd);
    pOrg = (LPSTR)apxPoolRealloc(hPool, pOrg, len);
    if (pOrg) {
        if (nas)
            *pOrg = '\0';
        if (szStr)
            lstrcatA(pOrg, szStr);
        if (szAdd)
            lstrcatA(pOrg, szAdd);
    }
    return pOrg;
}

static LPSTR __apxEvalPathPart(APXHANDLE hPool, LPSTR pStr, LPCSTR szPattern)
{
    HANDLE           hFind;
    WIN32_FIND_DATAA stGlob;
    char       szJars[MAX_PATH + 1];
    char       szPath[MAX_PATH + 1];

    if (lstrlenA(szPattern) > (sizeof(szJars) - 5)) {
        return __apxStrnCatA(hPool, pStr, szPattern, NULL);
    }
    lstrcpyA(szJars, szPattern);
    szPath[0] = ';';
    szPath[1] = '\0';
    lstrcatA(szPath, szPattern);
    lstrcatA(szJars, ".jar");
    /* Remove the trailing asterisk
     */
    szPath[lstrlenA(szPath) - 1] = '\0';
    if ((hFind = FindFirstFileA(szJars, &stGlob)) == INVALID_HANDLE_VALUE) {
        /* Find failed
         */
        return pStr;
    }
    pStr = __apxStrnCatA(hPool, pStr, &szPath[1], stGlob.cFileName);
    if (pStr == NULL) {
        FindClose(hFind);
        return NULL;
    }
    while (FindNextFileA(hFind, &stGlob) != 0) {
        pStr = __apxStrnCatA(hPool, pStr, szPath, stGlob.cFileName);
        if (pStr == NULL)
            break;
    }
    FindClose(hFind);
    return pStr;
}

/**
 * Call glob on each PATH like string path.
 * Glob is called only if the part ends with asterisk in which
 * case asterisk is replaced by *.jar when searching
 */
static LPSTR __apxEvalClasspath(APXHANDLE hPool, LPCSTR szCp)
{
    LPSTR pCpy = __apxStrnCatA(hPool, NULL, JAVA_CLASSPATH, szCp);
    LPSTR pGcp = NULL;
    LPSTR pPos;
    LPSTR pPtr;

    if (!pCpy)
        return NULL;
    pPtr = pCpy + sizeof(JAVA_CLASSPATH) - 1;
    while ((pPos = __apxStrIndexA(pPtr, ';'))) {
        *pPos = '\0';
        if (pGcp)
            pGcp = __apxStrnCatA(hPool, pGcp, ";", NULL);
        else
            pGcp = __apxStrnCatA(hPool, NULL, JAVA_CLASSPATH, NULL);
        if ((pPos > pPtr) && (*(pPos - 1) == '*')) {
            if (!(pGcp = __apxEvalPathPart(hPool, pGcp, pPtr))) {
                /* Error.
                * Return the original string processed so far.
                */
                return pCpy;
            }
        }
        else {
            /* Standard path element */
            if (!(pGcp = __apxStrnCatA(hPool, pGcp, pPtr, NULL))) {
                /* Error.
                * Return the original string processed so far.
                */
                return pCpy;
            }
        }
        pPtr = pPos + 1;
    }
    if (*pPtr) {
        int end = lstrlenA(pPtr);
        if (pGcp)
            pGcp = __apxStrnCatA(hPool, pGcp, ";", NULL);
        else
            pGcp = __apxStrnCatA(hPool, NULL, JAVA_CLASSPATH, NULL);
        if (end > 0 && pPtr[end - 1] == '*') {
            /* Last path elemet ends with star
             * Do a globbing.
             */
            pGcp = __apxEvalPathPart(hPool, pGcp, pPtr);
        }
        else {
            /* Just add the part */
            pGcp = __apxStrnCatA(hPool, pGcp, pPtr, NULL);
        }
    }
    /* Free the allocated copy */
    if (pGcp) {
        apxFree(pCpy);
        return pGcp;
    }
    else
        return pCpy;
}

/* ANSI version only */
BOOL
apxJavaInitialize(APXHANDLE hJava, LPCSTR szClassPath,
                  LPCVOID lpOptions, DWORD dwMs, DWORD dwMx,
                  DWORD dwSs, DWORD bJniVfprintf)
{
    LPAPXJAVAVM     lpJava;
    JavaVMInitArgs  vmArgs;
    JavaVMOption    *lpJvmOptions;
    DWORD           i, nOptions, sOptions = 0;
    BOOL            rv = FALSE;
    if (hJava->dwType != APXHANDLE_TYPE_JVM)
        return FALSE;

    lpJava = APXHANDLE_DATA(hJava);

    if (lpJava->iVmCount) {
        if (!lpJava->lpEnv && !__apxJvmAttach(lpJava)) {
            if (lpJava->iVersion == JNI_VERSION_1_2) {
                apxLogWrite(APXLOG_MARK_ERROR "Unable To Attach the JVM");
                return FALSE;
            }
            else
                lpJava->iVersion = JNI_VERSION_1_2;
            if (!__apxJvmAttach(lpJava)) {
                apxLogWrite(APXLOG_MARK_ERROR "Unable To Attach the JVM");
                return FALSE;
            }
        }
        lpJava->iVersion = JNICALL_0(GetVersion);
        if (lpJava->iVersion < JNI_VERSION_1_2) {
            apxLogWrite(APXLOG_MARK_ERROR "Unsupported JNI version %#08x", lpJava->iVersion);
            return FALSE;
        }
        rv = TRUE;
    }
    else {
        CHAR  iB[3][64];
        apxLog(cAHANDLE hJava, LPCSTR szCln                       cp;
    }
    else
        return pCpyern, NULp,  }L:
            {
     SAFE_ 2              if (szSe (lpJava->iVeetar
       l_INDENT |  brea hCurr             if (szSe (lpJava->iVeetar
        return pCpyern, NULp,  }L:       Dn_ync;
  ""iB[3snueea h
      ;

    *lppArray = (JavpCpyapxStrn  dA      DWORD qr = apxStrppArray =e
    LP BOOL
aplpJvmr wturR pCpy u>iVtrnCatA(hPoO= apxS
   c61) * sizCpy,uion);
        if (Java->iVersetar
        return pC_hPart(APun);
        if (Java-i (Java->iVersetar
        return pC_hParmage            sipCpy;L>iVmNtrn  dA      DWORD qr =PCSTR szStr, int nCh)
{
    LPSTR pStr;1uAr(HWnupxLog(cAHANDLE hJavE(lpiava);    }E nCh)
{
    LPSTR pStr;1uAr(HWnupxLog(c     Careturn  && lpJava->lpJvm) {L-PXLOG_MARK_INFO "%s", s SAFE_ 2              if (s;
   r,PCV, s SAFE_ 2             Ng == NULL;
 ateThl3g    == NULL;
    if (pOrg)
        len += ,/Pattern) > (sizeof(szJars) - 5)) {
     ret_+ sizeoava->iVerse(sE ,/Pattern) > (sizeof(szJars) - 5)) {
  steriiopy */
    if        return szUser;
    enur wturR pCpy u>iVtr
  i_MARK;';
E if        return szUser;
    enur wturR2,
 CaRSION_1_.rn s dA     * a hook for a function tif (!_st_syanHANDLE hJavE(lpiava);    }E nCh)
{
    LPSTR pSM-zeof(szJars) - 5)) {
 aA     }
        rv = TRUE;>iVl4_ }E nCh)"/Pattern) > (sizeof(szJ
 aA     }
        rv = TRUE;>iVl4_ }E D_DAl    rv =tern) > (si   NDLE hJavE(lpiava);hurn the ormbars) - 5)) {
 aA     rsyanHAN                FreeL-PSTR)apxPoolRealloc(hPosyanHAN  e trailin E;
    pJavapPttio)ion tifpr,{
x_INDEN   nChNULL, JlrJars) - _ol, pGcthPart(h   ifif (Java->iVersetar
        return pC_hPBex nChPoorsetar
 apPttio)ion tie;
    }
_ClassPato far.ie 5)) {
 aA3nse.  Yo             {
 aA3nse. lN_          if _       p        rR 
    FilN_              (DLGPROC)__nCh)"/Pattern) > (sizeof(szJ
 aA     }
  (hPooool, pGcp== JN_szJ
 aAr, LPCSTR szAdd)
{
    VmCount = iVm->i;hur     }
    elLPCVO** Yo             {
 aA3nse. lVM lpJavEMON-((pPos {
 aA3nse. lVM lpJavEMON-((pPos {
 aA3nse.      (VCLAZZ(lpJava, clWork     rR 
    FilN_n) > (sizeof(szJ
 aA  Java->iVersion = JNICALL_0(GetVersion);
/_;
    ANDNn2_MARo A"attern) > (sizeof(szJ
4ICALL_0(GetVersion);
/_;
    ANDNn2_MARolC. lVM lpJavEMON-((pPos {
 aA3nse. lVM lpof(sn_((pPos g;LL, JlrJars) - _ol,etVTString);
                __apxJvmDetach(l)ion pqr =PCSTR szSL"ol,  Aing);
 lpJav**ARo A"attern) > (sizeof(szJ
va->lpJvSL"ol,  Aing);
 lpJav        _a->lpJvS if        return szUser;tic LPSTL A"a lpJav   {
   }
     "-----------------------------eL-PL    aJavE(lpiD_lpJava-Returni
 User;tic LPSTL A"a lpJav  ap"io)i CSTR szSL"ol,  AinetVTg(magLPSTL A"a lpJl, r           (DLGPROC) lpnas)
           return szUser;tic LPSTle excepn_sizeof(("a lpJav  ap"io)i CSTR szSL"ol,  o A"aio)*_ic LPSTl     eW(,cbn) > (sizeof(szJ
 LPSC)
                *lpAttachel--------------------------------- > CatA(hPool, _ars) - __

    eturn szUse(Oeturn tL pqrnHAN  e trailin E;
    pJ return L  err FALSE;cp = __le __apxStl, ".j_N  e traRvm)C_cp = __lUse(2;
/* Stand lPST0;
    charlm)C_cp = p++x(szJUse(2;
/* St(2tte----------
#endif

n_ }
    cb JNI_VERSION_1_1;
 i ap"AJavglobbinl---
#entic Li(M  lpJava;
    js bJniVfpxp,  }"aA
#eno far.
L
 USreeN,  }tA(hPool, ,turnle __apxStl, "{
 NALSE;cp = __le __apxStl, "_*);
st-
# "{T4ue __apxStl, "{
 NALSEetuSE;)E;cp = pr,"{T4ue, "MRYxCSTR szSL"ol, (pGcp)
       =avEMOe
#end"MRYxCSTR szSL"ol, (pGc", s SAFE_ 2              if (s;
   O       retuS(llJvmPaC*cbg);
 lpJav        _a0 pr,E**ARo A"attern) > (sizeof(szJ
va->lpJvSLgBu,rni
 User;ts; D_lpJava-Returni
void **), s (T- > C,  }"aA
#entL pqrnHAN  e Hr, ifJavEMO   e
sf

n_ }
_E;
   i  sipCpy;L>iVm_= NULL;JN_szJ
 aA l      l++cp = __apxEvalPathPart(-PL    aJavE(lpiD_lpJava-Returni
 User;lpJava;/PathPJavE(lpiD_lpJava-Returni
 UsARE(JNI_GetCreatedJavaze = = APXesU2

piD_lpJao-Re*_       it;0J
 aA     }
        rv = TRUE;>iVl4_ }E 
_E;
   i  sipCpy;L>iVm_= NULL;JN_szJ
E;cp = __le __apxStl, "_*);ni
void **)_apuer;l     retuS(llJ P2traiiavp = __SE_HA*_MOe
#en_
    Fivp = __SC; D_lpJava-Returni
void **), s (T- > C,  }MOe
}
-RavaTao-Re*_       it;0J
 aA     }
        r = APXesU2

piD_lpJao;
   i  sipCpy;L>iVm_= NULL;JN_szJ
E;c    ""0J
avarsipCpy;L"wava/lang/String"
#define MSVCRT7yTvars0L) > (sizeof(sd path element */
            if (!(pGcp = __apxStrnCatA(hPo= __FE_CLOSE_HANDLE(lpJava->hWorkerThread the origin!(pGcp = __apxStrnCatA(hPo= __&& !lpJEMPTY_ a4)  (Java-Returni          /*Java-Returnig"
muer"hPo= __&& !,E**AmpA( __SE_HA*_MO        ((*(lporte"_MARK_StrIndexA(LPCSTRUsend -;hurn  DWORit L;    ,ind, orcsion);
      /lang/Stringg"
#Is0L) >      /*Java-Returnig"

    }
   args);
   l if (pSM-zeofys_jvmDl.obalRe,     ,= __SE_HA*_M

static vol if (pSM-zeofys_jvmDl.oM;    ,i512,*Java-Returni lpof(sn_(----
#enE  _st_sys += lsPosya1, a2, a3, a4)  erThread the --------- >      /*gle jvm can exist pe   DYNLOAD_FPTR_LOenur wturR pCpy u>iVtr
  i_MAR += lsPos " a1, a2, a3, a4)  \"tr, inteturn szUser;
        }
    }
    /* pSM-zeofysT7yTva.----
#enE  _st_sysNewPORTED
#, --------   /* E(JNI_GetCreated--------   /* STR szStN_1_1;
 ion);
  ----
##enE  _st_sys += lsPosya __SE_HA*_M

stati the --------- >      /*gle jvm can exist pe   DYNLOAD_FPTR_LOenur wturR pCpy u>iVtr
  i_MAR += lsPos %str, inteya __SE_HA*_M

statiser;
        }
    }
    /* STRM      1_1;
 i      ind,NULL;->lpEnv))->Exc    a== '*'on);
  pSM-zeofys_jvmDl.----
##enE  _st_sysNewPORTED
#, --------   /* E(JNI_GetCreated--------  );
  pSM-zeofys_jvmDl.-va-Ret#enE  _st_s3    S  lstM;      rn) > (sizeof(szJars) - 5)) {
  steriiopy *pSM-zeofys_jvmDl.----
rn) > (sizeof(szJars) - 5)) {
  steriiopy *Java-Returni /lang/StrinerThread the originofys_jvmDl.-va-Ret--- >      /*gle jvm can exist pe   DYNLOAD_FPTR_LOenur wturR pCpy u>iVtr
  i_MARva-Ret#'  if (WaitFo%s(T7yTva[])'llPath;
  in lsPos %scrtBinPath, SIZ_PATHJava-Returni /l_SE_HA*_M

statiser;
        }
    }
    /* && !,E**AmpA( __SE_HA*_MO        ((*(lporte"_--- >      /*n }
       BOOL    Cpy;LW = FALSE;
    ifRavaTao-R;
  ALID_HANDLE(py *pSM-zeofys_jvmDl.- }
   E  _st_s3 New      1.vers*n }
rn) > (sizeof(szJars) - 5)) {
  steriiopy */pSM-zeofysT7yTva.----
is replaced by *.jar wn  if  i
 UsARE(JNI_G break;
            }ser;tic LPSTL A"lpJaoReturni
 UsARE(JNI_GGGGGjFindNexa
    etDllDirecNewpParamete ALIDvaz,            ALIDvazight - SUMIN_WIDTH;
E  _st_s3 Set      1.verEtrnCat,*pSM-zeofys_jvmDl.- }
t nCxa
 [i] == L'/') {
                jreBinPath[i] = L'\a
 vzStr,= %Snt nCte ALIDvaz[i] == L'/') {
           * Do a glob4_ }E nCh)ALID_HANDLE(mDllHandle = NULL;
      STRM obj)CLOS);
        ->lpEnv))->Exs)
IL;-ill laun'*'_CLOSm     
  wait Jvm)     nv))finishes        ->lpJvm = NULL;
            _SYSERR);
 eak;
        default:
 pEnv))->= NKER_->ri(    do {r a fux; goto)finished; }iD_lpJ(ava->iVe = NUL a fu     p  i  sipCpy;L>iVm_= ANDLE hPool, LPS sipCpy_THREADARGS   }
   (PS sipCpy_THREADARGSurn TRUE;
}

APX  retuS(llJ P2t-  );
    if (   (  retuS(l)  }
SE;m_= NULL;Jof(sd path element */
            if (!(pGcp = __= NKER_->ri(
    (*lpFE_CLOSE_HANDLE(lpJava->  }
SE;m_= erThread the origin!(pGcp = __= NKER_->ri(
    (*lp the ULL, JAVA_CLASSPAT  }
SE;m_= rn) > (sizeof(szJars) - 5)) {  }
SEpPos > pPtr) && (*(pPos - 1) ==  - 5)) {  }
SEif (hJava->dwType != APXHANDLE_TYPE_JVM  }
SE
x_IN  }
SE
xxIN  }
SE
Sa->dwType != APXHANDLE_TYPE_JVM  }
SElpJava)) {
 E_ATTRIBUTES)  NKER_->ri(2)    }
    /* && !  }
SEpPitArgs)

    i  }
SEpPitArgs)

return 0;
}
    WCHAR  jreBinPath[SIZ_PATHLEN];
        WCHAR  crtBin if (jreBinPath[i] == L'\\' ||   }
SEpPitArgs)

rOAD_FPTR_LOenur wturR pCpy u>iVtr
] = L'\             lst
  rlcpyW(crtBinPath, SIZ_PATHLEN,  }
SEpPitArgs)

rOAD_FPT}  (*lp the ULL, JA*)_apuer;l     }
SE;m_= rn) > (sizeof(szJars) - 5)) { {  }
SEpPos > urni
void **), s (T- > C,  5)) { {  }
SEpPva-Returni
void **), s (T- > C,  5)) { {  }
SE
-RavaTao-ReE_ATTRIBUTES)  NKER_->ri(3rOAD_FPT}  (*lpULL, JASet ut   }
SE;m_= rNULL;,{  }
SEpPStdErrif (n*_M

statiULL, JASet ut   }
SE;m_= rN  }
,  }
SEpPStd utif (n*_M

s   /* STRreatedJavwe have    sPos oid * L;    - > C,  }"aA
 originofys_jvmDl.----
#xHeapSize;
ys_jvmDl.-va-Ret-TTRIBUTES)  NKER_->ri(4    (*lp the pxStrnCatA(hPool, NULL,TTRIBUTES)  NKER_->ri(5

statiULLy;L>iVmNtrn  dA      DWORD qrCLOSW>lpEnv))->ExcCp)
   %s:%scrtBinPath, SIZ_PATHpSM-zeofys_jvmDl.obalRe, pSM-zeofys_jvmDl.oM;    erThread);
               (*(  if (lpStr  crvao-PXLOG_MARK_SYSERVA_C--   /* STREnsringULL, JASp)
 ->lpEnvharg =ExcourcCp)(*(  > C,  }                    XLOG_MARK_SYSER    , INFINITE--   /* E(J_st_s3 += lS  lstVitFM;    ,tBinPath, SIZ_PApSM-zeofys_jvmDl.----
rn) > (sizeof(szJpSize;
ys_jvmDl.-va-Retrn) > (sizeof(szJpSize;
ys_jvmDl.-ALID_HANDLE( thedefine JNI_VERSION_Dl, NULL, JAVA_CLASSPJECT_0)
            rv = TRUE;
vaVM) =vhargbee }
rowneturn szUser;n rv;
    }1urn szUser;_DECl, NULLLL, jint)(JavaVM **, void **, l, NULLLL, jinturn szUser;mDllHandle);
    DYNLOAD_FPTR_LO  NKER_->ri(6rOAD_FPT}  (*lp dA     * a hookmDllHandle);
    DYNLOAD_FPT}  finished:   /* && !,  DYNL JAVA_CLASSPATH                (*(  i0OAD_FPTR_LOenur wturR pCpy u>iVtr
] = L'\rCLOSW>lpEnv))->Excfinished %s:%sSTR szCp)(*(=iter
void **), s (T- > C, pSM-zeofys_jvmDl.obalRe, pSM-zeofys_jvmDl.oM;    ,L aLOAD_FPTR_LO  crvao-PXLOG_MARK_SYSERVA_C--   /* }  (*lprv;R);
 e aLOAD_FPTSTRn(*(lpgets RIBUTrrorkeep   1_1ompf (rde = y    jreBinPath[i }
      *);ni
void *Sp)
(PS sipCpy_THREADARGS  }
h path to '%S'",
                 FE_CLOSE_HANDLE(lpJava->  }
SE;m_= erThread the origin!(pGcp = __apxStrnCatA(hPo= __FE_CLO             (*(  i0OAD_FPTXLOG_MARK_SYSERVA_C_FPTOAD_FPTRrvao-Ph
 *   }
,  }
, replaced byXLOG_MARK_SYSER    _FPTOAD_FPTRrvao-Ph
 *   }
,  }
, replaced byXLOG_MARK_SYSERR);
 PTOAD_FPTR(JNI_GetCrean) > (sizeof(szJars) - 5)) {
  steriiopy */       FreeLibrary(an) > (sizeof(szJars) - 5)) {
  steriiopy */         _SYSERR);
 an) > (sizeof(szJars) - 5)) {
  steriiopy */p }
t CREATE_SUSPENDE rn) > (sizeof(szJars) - 5)) {
  steriiopy *
    jintxceptionDescr  TerminateThread(lpJava->hWor       _st_sys_jvmDllHandle = LoadL   }
                l++;
            }
        }
    }
    /* ResaTation */
    SetErrorMode(erLOAD_FPTSTRWait Jvm)    1_->lpEnv))->Excep_CLASSPA(  > C,  }                    XLOG_MARK_SYSERVA_C, INFINITE--   /* lPathPart(hP           (*(   Java->iVersion = JNI  }
    }
  crvao-PXLOG_MARK_SYSER    --   /* lPathE**AmpA(pSM-zeofys_jvmDl.obalRe,        ((*(lporte"_--- >      /*_DELive sava-m)
 rlcep_CLASSPAe)
{)->Exs)))))))))
    turnw
  ec(hPodNexpported JNI 0)47: Invalid RunVMs,-ill be hanl';
  _one
       47: Invalid Rn);
      Sleep(1000--   /* }  (*lpdle = NULL;
       ormbars) - 5)Set ;
    lpJava->iVmm_= rNthPart(hattern)     LPSTR p;
(hargm) {L-PXLOG_MA'%S'",
             ULL;Jof(sd path element */
            if (!(pGcp = __n = JNICALL= __FE_CLOSE_HANDLE(lpJava->hWorkerThread(hargm) {L-PTR pSM-zeof != JNI_OK)

#pSM-zeof != JNI_OTR  != JNI_OK)

#n = JNI(hargm) {L-PXLO      ormbars) - 5)     lpJava->iVmm_= rNthPart(hMilliseite(sr impl bKill     LPSTR p;
         '%S'",
             ULL;Jof(sd path element */
            if (!(pGcp = __n = JNICatA(hPo= __FE_CLOSE_HANDLE(lpJava->hWorkerTh C,  }"aA
 originof           (*( 
        iftErrorMode(erL(pGcp = __n = JNIack);
    ifK)

#na fu                    XLOG_MARK_SYSERode(errM(hMilliseite(s--   /* lPatna flback);TIMEOUT 
  bKill     * a hookmDllHaaLOAD_CALL(SetDmm_= rN= LoadLi }
 0--   /* }   jreBinPath[i }
      ak;
 ars) - 5))_FPTRos > V   retuS(llJ P2traiiavp = __SE_HA*_MOe
#en_
    Fivp = __, l = 0;
ng/StrinvaDestroyTl  }
h path to '%S'",
    = __FE_CLONULL;JN_szJ
E;c      cjClazz = NULL;             cite     \
                cinst   ULL;Jof(sd path element */
            if (!(pGcp = __n = JNILE hPool, LFE_CLOSE_HANDLE(lpJava->hWorkerThread the pxStrnCatA(hPool, NULL,TTRIBUTES)
                  c--
#enE  _st_sys += lsPosya __SE_HA*_M

stati thec--
#eNDLE h#xHeedefine JNI_VERSION_Dl, NULL,--- >      /*gle jvm can exist pe   DYNLOAD_FPTR_LOenur wturR pCpy u>iVtr
  i_MARCouldllPat += lsPos %seya __SE_HA*_M

statiser;
      nCatA(APXHANDL      cite #enE  _st_s3    M;      r c--
,  <ep_C>" /lang/StrinerThread thecite #eNDLE h#xHeedefine JNI_VERSION_Dl, NULL,--- >      /*gle jvm can exist pe   DYNLOAD_FPTR_LOenur wturR pCpy u>iVtr
  i_MARCouldllPatfszStC(NULPARAor %stror %ser
void **), s (T- > C, ;
ng/Strinva __SE_HA*_M

statiser;
      nCatA(APXHANDL      cinst   E  _st_s3 New      Vr c--
, cite Cte ALIDerThread thecinst  NDLE h#xHeedefine JNI_VERSION_Dl, NULL,--- >      /*gle jvm can exist pe   DYNLOAD_FPTR_LOenur wturR pCpy u>iVtr
  i_MARCouldllPatc_FPTR instance    %ser
void **), s (T- > C, ;_SE_HA*_M

statiser;
      nCatA(APXHANDL      
      cinst        ak;
 ars) - 5))_FPTRos >    retuS(llJ P2traiiavp = __SE_HA*_MOe
#en_
    Fivp = _, l = 0;
ng/Strinva...h path to '%;
           DestroyThrea         DesCp)
(a}
t /lang/StrinerThreadna fus) - 5))_FPTRos > V J P2tra __SE_HA*_MO ;
ng/StrinvaALID_HANDLE(Desend(ALID_HAN jreBinPath[i }
      ak;
 ars) - 5))_FPTRpParamA   retuS(llJ P2traiiavp = _
{
    ath to '%S'",
    = __FE_CLONULL;JNFindNexsrn)
{
    HANd path element */
            if (!(pGcp = __n = JNILE hPool, LFE_CLOSE_HANDLE(lpJava->hWorkerThool, Ls     E  _st_sysNew
{
 UTF,= _
{
  rThread theslstrlenA(p#xHeedefine JNI_VERSION_Dl, NULL,--- >      /*gle jvm can exist pe   DYNLOAD_FPTR_LOenur wturR pCpy u>iVtr
  i_MARCouldllPatc_FPTR FindNexror %ser
void **), s (T- > C, ;
vE(lpiava);    }E
      nCatA(APXHANDL      
      sAdd)
    ak;
 ars) - 5))_FPTRpParamW   retuS(llJ P2traiiaWvp = _
{
    ath to '%S'",
    = __FE_CLONULL;JNFindNexsrn)
{
    HANd path element */
            if (!(pGcp = __n = JNILE hPool, LFE_CLOSE_HANDLE(lpJava->hWorkerThool, Ls     E  _st_secNewpParamet _
{
 ,_apxStl, "{
{
   rThread theslstrlenA(p#xHeedefine JNI_VERSION_Dl, NULL,--- >      /*gle jvm can exist pe   DYNLOAD_FPTR_LOenur wturR pCpy u>iVtr
  i_MARCouldllPatc_FPTR FindNexror %Ser
void **), s (T- > C, ;
vE(lpiava);    }E
      nCatA(APXHANDL      
      sAdd)
    jvaluears) - 5))= lS  lstM;    V   retuS(llJ P2traN_szJ
lplsPosyaC; D_lpJava-Returni
void **), s (T- > C,   to '%l = 0;
ng/StrinvaDestroyTl  }
h path to '%S'",
    = __FE_CLONULL;JNL;             L;    NULL;JNvalue> C,   to          '%Cpy;L"wava C, ;rsion
ng/StrinrThreadna. _       p      d path element */
            if (!(pGcp = __n = JNI         FE_CLOSE_HANDLE(lpJava->hWorkerThool, LD_lpJao-s    ift */')'    rR 
    s    p      ift */')' jint rv;
    CHAR XHANDLE_TYPE_JVM;
    lpJava   s    p  ma-Ret#enE  _st_s3    S  lstM;      r
lplsPosyaJava-Returni /lang/StrinerThread thema-Ret#elenA(p#xHeedefine JNI_VERSION_Dl, NULL,--- >      /*gle jvm can exist pe   DYNLOAD_FPTR_LOenur wturR pCpy u>iVtr
  i_MARCouldllPatfszStma-Ret#%sSTR szCng/String%ser
void **), s (T- > C, ;va-Returni /lang/StrinerThread
    CHAR XHANDLE_TYPE_JVM
       *f  i
 UsARE(J     'V'braryExW(dllJvmE(J_st_s3 += lS  lstVitFM;    Vr
lplsPosyaL;    ,i  ALID_HANDLE(py *ary(_st_sys_jvmD     'L'braryExW(dl     '['braryExW(dllJvmna. _  E(J_st_s3 += lS  lst      M;    Vr
lplsPosyaL;    ,i  ALID_HANDLE(py *ary(_st_sys_jvmD     'Z'braryExW(dllJvmna.z_  E(J_st_s3 += lS  lstBooleanM;    Vr
lplsPosyaL;    ,i  ALID_HANDLE(py *ary(_st_sys_jvmD     'B'braryExW(dllJvmna.b_  E(J_st_s3 += lS  lstByteM;    Vr
lplsPosyaL;    ,i  ALID_HANDLE(py *ary(_st_sys_jvmD     'C'braryExW(dllJvmna.c_  E(J_st_s3 += lS  lstCharM;    Vr
lplsPosyaL;    ,i  ALID_HANDLE(py *ary(_st_sys_jvmD     'S'braryExW(dllJvmna.i_  E(J_st_s3 += lS  lstShor M;    Vr
lplsPosyaL;    ,i  ALID_HANDLE(py *ary(_st_sys_jvmD     'I'braryExW(dllJvmna.i_  E(J_st_s3 += lS  lstIn M;    Vr
lplsPosyaL;    ,i  ALID_HANDLE(py *ary(_st_sys_jvmD     'J'braryExW(dllJvmna.j_  E(J_st_s3 += lS  lstLongM;    Vr
lplsPosyaL;    ,i  ALID_HANDLE(py *ary(_st_sys_jvmD     'F'braryExW(dllJvmna.f_  E(J_st_s3 += lS  lstFloa M;    Vr
lplsPosyaL;    ,i  ALID_HANDLE(py *ary(_st_sys_jvmD     'D'braryExW(dllJvmna.d_  E(J_st_s3 += lS  lstDoubleM;    Vr
lplsPosyaL;    ,i  ALID_HANDLE(py *ary(_st_sys_jvmDllHandle);
          2) {
                apxLogWrite(APXLOCng/String%sxror ma-Ret#%scrtBinPath, SIZ_PATHLEN, jre;
ng/Strinva _va-Returni lporyExW(dllJvmn CHAR XHANDLE_Tpy *ary(_st_sys_}   jreBinPath[i }
      jvaluears) - 5))= lS  lstM;       retuS(llJ P2traN_szJ
lplsPosyaC; D_lpJava-Returni
void **), s (T- > C,   to, l = 0;
ng/Strinva...h path to Nvalue>         DestroyThrea         DesCp)
(a}
t /lang/StrinerThreadna fus) - 5))= lS  lstM;    V J P2tralplsPosyaJava-Returni /lang/StrinvaALID_HANDLE(Desend(ALID_HAN jreBinPath[i }
      /n += ls) {
P2te);*xpportedset ut new P) {
vEeam new if ( utpu
vEeam ff (n*_M
  rThrA(hPool, NULL, JASet ut   retuS(llJ P2traimpl s crtBinOr utraiiaWvp = _if (n*_M
 path to '%S'",
                             fs                   ps        FindNex    fif (s;
N_szJ
E;c  sya             d path element */
            if (#xHea _if (n*_M
 pW(dllJvmn CHAR CatA(hPo= __FE_CLOSE_HANDLE(lpJava->hWorkerThread the pxStrnCatA(hPool, NULL,TTRIBUTES)
     CatA(hPool, pG1] = fn fus) - 5))_FPTRpParamW J P2tra _if (n*_M
)trlenA(pOrg);
    apxStrnCatA(hPo= __&& !(fs fus) - 5))_FPTRos >  J P2tra      io/if ( utpu
vEeamome);
            lstrlcatW(jreAltPa"(efine MSVCRT7yTvarZ)V", fi, E(JNULL;
)trlenA(pOrg);
    apxStrnCatA(hPo= __&& !(ps fus) - 5))_FPTRos >  J P2tra      io/P) {
vEeamome);
            lstrlcatW(jreAltPa"(efine io/ utpu
vEeam;)V", fs
)trlenA(pOrg);
    apxStrnCatA(hPo= __sya#enE  _st_sys += lsPosya       ((*(lporte"_rThread thesys#elenA(p#xHeedefine JNI_VERSION_Dl, NULL,--- >      /*gle jvm can exist pe   DYNLOAD_FPTR_LOenur wturR pCpy u>iVtr
  i_MARCouldllPat += lsPos       ((*(lporte"_rThread    apxStrnCatA(hPo= __}Pool, pG1] =s crtBinOr ut)AD_FPTR_LOenu- 5))= lS  lstM;     J P2tra ysya s crtB", "(efine io/P) {
vEeam;)V", pD_HANDLE(;
    lpJava enu- 5))= lS  lstM;     J P2tra ysya s c ut", "(efine io/P) {
vEeam;)V", pD_HANol, pG1] =define JNI_VERSION_Dl, NULL, JAVA_CLASSPgle jvm can exist pe   DYNLOAD_FPTR_LOenur wturR pCpy u>iVtr
  i_MARrtBinc(hPodNex
  ma-Ret#ror       ((*(lporte"_rThread    apxStrnCatA(hPo= __}PoDLE(;
    lpJava dle = NULL;
 LO      ormb     }V rv;
   zeoav, JAVA_CLdle = Nn rv;
   
      aitFof(JA}V rv;
   z ormb ;
       JAVA_CLn rv;
    }
    else
        return FALaitF NULL, JA    if (IS_IN   retuS(llJ P2t
 path to impl btA(hPoe_ClassPatS'",
                 E  trin* strinNULL;JN_szJ
E3g    == NULL;
  

    if (IS_IN)#elenA(p#xH   lpJava   if (GlenA(p#xH   lpJava   if h element */
            if (!(pGcp = __n = JNhPo= __FE_CLOSE_HANDLE(lpJava->hWorkerThread thepxStrnCatA(hPotri_CreateJa& striJa&btA(hPoe)return 0;
}
    WCHAR    

    if (IS_IN)( striJa replaced by *.jar wbtA(hPoe)e);
         (*   len += ,/Pat return NULL;


    /*en += ,/PathPo= __}Po}Po                                                                                                                                                                                                                                                                                                                                                                                                                            i
vons-daevon-1.0.15-/Stive-src/w+= ows/resources/license.rtf                                      100664   25140   25140        13102 12125036546  24176  0                                                                                                    uCp)   m= Jk                           m= Jk                                0       0                                                                                                                                                                         {\rtf1\ansi\ansicpg1252\uc1\llHf0\stshfdbch0\stshfloch0\stshff (n0\stshfbi0\llH ((*1033\llH ((*fe1033{\fonttbl{\f0\froman\fatic
 238\fprq2{\*\pano   02020603050405020304}Javas New Roman;}Po{\f1\fswiss\fatic
 238\fprq2{\*\pano   020b0604020202020204}Arial;}{\f39\froman\fatic
 0\fprq2 Javas New Roman;}{\f38\froman\fatic
 204\fprq2 Javas New Roman Cyr;}{\f40\froman\fatic
 161\fprq2 Javas New Roman Greek;}Po{\f41\froman\fatic
 162\fprq2 Javas Ne